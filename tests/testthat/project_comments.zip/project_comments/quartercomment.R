
# This is a comment
getwd()
x <- 10+1
y = "hello"
